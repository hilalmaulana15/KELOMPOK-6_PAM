package com.example.crudtoko

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class BarangAdapter(
    private var barangList: List<Barang>,
    private val db: DatabaseHelper
) : RecyclerView.Adapter<BarangAdapter.BarangViewHolder>() {

    inner class BarangViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvNama: TextView = itemView.findViewById(R.id.tvNama)
        val tvKategori: TextView = itemView.findViewById(R.id.tvKategori)
        val tvHarga: TextView = itemView.findViewById(R.id.tvHarga)
        val tvStok: TextView = itemView.findViewById(R.id.tvStok)
        val btnEdit: ImageView = itemView.findViewById(R.id.btnEdit)
        val btnDelete: ImageView = itemView.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BarangViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_barang, parent, false)
        return BarangViewHolder(view)
    }

    override fun onBindViewHolder(holder: BarangViewHolder, position: Int) {
        val barang = barangList[position]
        holder.tvNama.text = "Nama: ${barang.nama}"
        holder.tvKategori.text = "Kategori: ${barang.kategori}"
        holder.tvHarga.text = "Harga: Rp${barang.harga}"
        holder.tvStok.text = "Stok: ${barang.stok}"

        // Tombol Edit
        holder.btnEdit.setOnClickListener {
            val context = holder.itemView.context
            val intent = Intent(context, UpdateBarangActivity::class.java)
            intent.putExtra("id_barang", barang.id)
            intent.putExtra("nama_barang", barang.nama)
            intent.putExtra("kategori", barang.kategori)
            intent.putExtra("harga", barang.harga)
            intent.putExtra("stok", barang.stok)
            context.startActivity(intent)
        }

        // Tombol Delete
        holder.btnDelete.setOnClickListener {
            db.deleteBarang(barang.id)
            refreshData(db.getAllBarang())
            Toast.makeText(holder.itemView.context, "Data Berhasil Dihapus!", Toast.LENGTH_SHORT).show()
        }
    }

    override fun getItemCount(): Int = barangList.size

    fun refreshData(newList: List<Barang>) {
        barangList = newList
        notifyDataSetChanged()
    }
}
