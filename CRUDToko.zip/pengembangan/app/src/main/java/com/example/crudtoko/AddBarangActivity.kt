package com.example.crudtoko

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AddBarangActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_barang)

        db = DatabaseHelper(this)

        val namaEditText = findViewById<android.widget.EditText>(R.id.namaEditText)
        val kategoriEditText = findViewById<android.widget.EditText>(R.id.kategoriEditText)
        val hargaEditText = findViewById<android.widget.EditText>(R.id.hargaEditText)
        val stokEditText = findViewById<android.widget.EditText>(R.id.stokEditText)
        val saveButton = findViewById<android.widget.Button>(R.id.saveButton)

        saveButton.setOnClickListener {
            val nama = namaEditText.text.toString()
            val kategori = kategoriEditText.text.toString()
            val harga = hargaEditText.text.toString().toIntOrNull() ?: 0
            val stok = stokEditText.text.toString().toIntOrNull() ?: 0

            if (nama.isNotEmpty() && kategori.isNotEmpty()) {
                val barang = Barang(0, nama, kategori, harga, stok)
                db.insertBarang(barang)
                Toast.makeText(this, "Data Barang Berhasil Disimpan!", Toast.LENGTH_SHORT).show()

                // Kosongkan kembali input setelah disimpan
                namaEditText.text.clear()
                kategoriEditText.text.clear()
                hargaEditText.text.clear()
                stokEditText.text.clear()

                finish() // Tutup halaman setelah simpan
            } else {
                Toast.makeText(this, "Harap isi semua data!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
