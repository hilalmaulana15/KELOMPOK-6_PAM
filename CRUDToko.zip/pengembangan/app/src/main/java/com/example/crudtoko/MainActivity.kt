package com.example.crudtoko

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.crudtoko.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var db: DatabaseHelper
    private lateinit var adapter: BarangAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityMainBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        db = DatabaseHelper(this)
        adapter = BarangAdapter(db.getAllBarang(), db)

        binding.recyclerViewBarang.layoutManager = LinearLayoutManager(this)
        binding.recyclerViewBarang.adapter = adapter

        // Tombol ke halaman tambah data
        binding.btnTambah.setOnClickListener {
            val intent = Intent(this, AddBarangActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        // update data setelah kembali dari tambah barang
        adapter = BarangAdapter(db.getAllBarang(), db)

    }
}
