package com.example.crudtoko

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class UpdateBarangActivity : AppCompatActivity() {

    private lateinit var db: DatabaseHelper
    private var barangId: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_barang) // Gunakan layout yang sama

        db = DatabaseHelper(this)

        // Ambil data dari Intent
        barangId = intent.getIntExtra("id_barang", 0)
        val namaAwal = intent.getStringExtra("nama_barang") ?: ""
        val kategoriAwal = intent.getStringExtra("kategori") ?: ""
        val hargaAwal = intent.getIntExtra("harga", 0)
        val stokAwal = intent.getIntExtra("stok", 0)

        // Temukan komponen
        val namaEditText = findViewById<EditText>(R.id.namaEditText)
        val kategoriEditText = findViewById<EditText>(R.id.kategoriEditText)
        val hargaEditText = findViewById<EditText>(R.id.hargaEditText)
        val stokEditText = findViewById<EditText>(R.id.stokEditText)
        val saveButton = findViewById<Button>(R.id.saveButton)

        // Isi nilai awal
        namaEditText.setText(namaAwal)
        kategoriEditText.setText(kategoriAwal)
        hargaEditText.setText(hargaAwal.toString())
        stokEditText.setText(stokAwal.toString())
        saveButton.text = "Perbarui Data"

        // Tombol simpan perubahan
        saveButton.setOnClickListener {
            val nama = namaEditText.text.toString()
            val kategori = kategoriEditText.text.toString()
            val harga = hargaEditText.text.toString().toIntOrNull() ?: 0
            val stok = stokEditText.text.toString().toIntOrNull() ?: 0

            val barangBaru = Barang(barangId, nama, kategori, harga, stok)
            db.updateBarang(barangId, barangBaru)
            Toast.makeText(this, "Data Berhasil Diperbarui!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
